package io.github.StardewValley.views;

import com.badlogic.gdx.Game;

public class MainMenuScreen {
    public MainMenuScreen(Game game) {
    }
}
